#include<iostream>
#include<string>
#include<stack>
#include<regex>
#include<vector>
using namespace std;

bool Pair(char opening, char closing)
{
	if (opening == '(' && closing == ')') return true;
	else if (opening == '{' && closing == '}') return true;
	else if (opening == '[' && closing == ']') return true;
	return false;
}

//check if braces are balanced
bool validateBraces(string exp)
{
	stack<char>  S;
	for (int i = 0; i<exp.length(); i++)
	{
		if (exp[i] == '(' || exp[i] == '{' || exp[i] == '[')
			S.push(exp[i]);
		else if (exp[i] == ')' || exp[i] == '}' || exp[i] == ']')
		{
			if (S.empty() || !Pair(S.top(), exp[i]))
				return false;
			else
				S.pop();
		}
	}
	return S.empty() ? true : false;
}

//if equation is quadratic
void solveQuad()
{
	float a, b, c, x1, x2, determinant, realPart, imaginaryPart;

	determinant = b*b - 4 * a*c;

	if (determinant > 0) {
		x1 = (-b + sqrt(determinant)) / (2 * a);
		x2 = (-b - sqrt(determinant)) / (2 * a);
		cout << "Roots are real and different." << endl;
		cout << "x1 = " << x1 << endl;
		cout << "x2 = " << x2 << endl;
	}

	else if (determinant == 0) {
		cout << "Roots are real and same." << endl;
		x1 = (-b + sqrt(determinant)) / (2 * a);
		cout << "x1 = x2 =" << x1 << endl;
	}

	else {
		realPart = -b / (2 * a);
		imaginaryPart = sqrt(-determinant) / (2 * a);
		cout << "Roots are complex and different." << endl;
		cout << "x1 = " << realPart << "+" << imaginaryPart << "i" << endl;
		cout << "x2 = " << realPart << "-" << imaginaryPart << "i" << endl;
	}
}

//if equation is Cubic
void solveCubic()
{

}

//if equation is Linear
void solveLinear()
{

}

//Check if equation has more equal signs to validate
bool equalSigns(string exp,int count,int i=0)
{
	
	if (exp.at(i) == '=')
	{
		count++;
	}
	if (count != 1)
		return false;
	else if (count == 1)
		return true;
	equalSigns(exp,count,i++);
}

//Check which type of equation degree (1,2 or 3)
void checkEq(string exp,int k)
{
	int m = 0,max=0;
	int degreeset[100] = { 0 };
	int pow;
	for (k; k < exp.size(); k++)
	{
		if (exp.at(k) == '^')
		{
			pow = exp.at(k+1) - '0';
			degreeset[m] = pow;
			m++;
		}
	}
	
	for (int i = 1; i<sizeof(degreeset); i++)
	{
		if (degreeset[i] > max)
			max = degreeset[i];
	}
	if (max == 2)
		solveQuad();
	else if (max == 1)
		solveLinear();
	else if (max == 3)
		solveCubic();
}

int main()
{
	int i = 0;
	int j = 0;
	string equation;
	//check validation using this regex
	regex first("([(]?(\\+|-)?([[:digit:]]+)?([x][^][1|2|3])?([)])?([=|+][[:digit:]]+))+");

	//prompt user to enter equation
	cout << "Enter your Algebraic equation in 1<=order<=3 x for variable example(ax^n+bx^n-1+...+c=0)" << endl;
	cin >> equation;

	//Check whether equation given is correct
	if (validateBraces(equation) && equalSigns(equation,0))
	{
		//Apply regex to decide if given equation is correct
		if (regex_match(equation,first))
		{
			checkEq(equation,0);
			
			cout << equation<<endl;
		}
		//In case given equation is wrong display error
		else
		{
			cout << "ERROR1!" << endl;
		}
	}
	//In case given equation is wrong display error
	else
		cout << "ERROR2!" << endl;

	system("pause");
	return 0;
}
